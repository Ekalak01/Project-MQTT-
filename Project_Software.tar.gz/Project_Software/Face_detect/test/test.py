from ftplib import FTP 
import os
import fileinput
 
localfile = "/home/s6301012620049/Desktop/c c++/Project/test/testing.png"
ftp = FTP()
ftp.set_debuglevel(2)
ftp.connect('25.43.97.26', 21) 
ftp.login('s6301012620049','Ryu4152611')
ftp.cwd('html/pic_upload')
fp = open(localfile, 'rb')
ftp.storbinary('STOR %s' % os.path.basename(localfile), fp, 1024)
fp.close()