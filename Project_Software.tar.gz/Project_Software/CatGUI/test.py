import paho.mqtt.client as mqtt  #import the client1
import time

def on_connect(client, userdata, flags, rc):
    if rc==0:
        client.connected_flag=True #set flag
        print("connected OK")
    else:
        print("Bad connection Returned code=",rc)
        client.bad_connection_flag=True

mqtt.Client.connected_flag=False#create flag in class
broker = "localhost"
client = mqtt.Client()        #create new instance 
client.on_connect=on_connect  #bind call back function
client.loop_start()
print("Connecting to broker ",broker)
try:
    client.connect(broker,1883) #connect to broker
    print("Connected")
except:
    print("Connection Failed")
    exit(1) #Should quit or raise flag to quit or retry

client.loop_stop()    #Stop loop 
client.disconnect() # disconnect