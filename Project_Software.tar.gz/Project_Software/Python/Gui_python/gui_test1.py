from Tkinter import *

root = Tk() #Makes the window
root.wm_title("Window Title") #Makes the title that will appear in the top left
root.config(background = "#FFFFFF")


def redCircle():
    circleCanvas.create_oval(20, 20, 80, 80, width=0, fill='red')
    colorLog.insert(0.0, "Red\n")

def grnCircle():
    circleCanvas.create_oval(20, 20, 80, 80, width=0, fill='green')
    colorLog.insert(0.0, "Green\n")

rightFrame = Frame(root, width=200, height = 600)
rightFrame.grid(row=0, column=1, padx=10, pady=2)

circleCanvas = Canvas(rightFrame, width=100, height=100, bg='white')
circleCanvas.grid(row=0, column=0, padx=10, pady=2)

leftFrame = Frame(root, width=200, height = 600)
leftFrame.grid(row=0, column=0, padx=10, pady=2)

Label(leftFrame, text="Status :").grid(row=0, column=0, padx=10, pady=2)
Label(leftFrame, text="___").grid(row=0, column=1, padx=5, pady=1)

if "rexd" == "red":
    Label(leftFrame, text="Online").grid(row=0, column=1, padx=5, pady=1)
    circleCanvas.create_oval(20, 20, 80, 80, width=0, fill='red')
else:
    Label(leftFrame, text="Offline").grid(row=0, column=1, padx=5, pady=1)
    circleCanvas.create_oval(20, 20, 80, 80, width=0, fill='green')



root.mainloop() #start monitoring and updating the GUI