# -*- coding: utf-8 -*-
# Author: 
# Company: 
#
# Program: 
#
#
# ----------------------------------------------------------------------------------------------------------------------
# Module
import paho.mqtt.client as mqtt
import json
import time
from threading import Thread
from datetime import datetime
from threading import Thread



# ----------------------------------------------------------------------------------------------------------------------
# Functions

# The callback for when the client receives a CONNACK response from the server.
def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))

    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    # Manual subscription to the topics of the charging stations on the sensor things server
    #for x in range(54, 758):
    #    client.subscribe("v1.0/Datastreams(" + str(x) + ")/Observations")
    client.subscribe("KJPIE")


def time_decode(unix_time):
    utc = datetime.fromtimestamp(unix_time)
    return utc


# The callback for when a PUBLISH message is received from the server.
def on_message(client, userdata, msg):
    payload = json.loads(msg.payload)
    utc = payload['timestamp']
    try:
        print(time_decode(utc))
    except Exception as e:
        print(e)
        print(e.args)
        print(payload)

    #print(datetime.utcfromtimestamp(payload['timestamp']).strftime('%Y-%m-%d %H:%M:%S'))



# ----------------------------------------------------------------------------------------------------------------------
# Main program

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

# client.connect("ip_adress", 1883, 60)
client.connect("localhost", 1883, 60)
client.loop_forever()
#thread2 = Thread(target=client.loop_forever)


#thread2.start()

