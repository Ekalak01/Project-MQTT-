
import paho.mqtt.client as mqtt

from Tkinter import *



cou = 0  
#print("cou = ",cou)
def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))
    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    client.subscribe("KJPIE")

# The callback for when a PUBLISH message is received from the server.
def on_message(client, userdata, msg):
  print(msg.payload.decode())
  global cou 
  cou +=1 
  print('cou = {}'.format(cou))



client = mqtt.Client()

client.on_connect = on_connect

client.on_message = on_message
client.connect("localhost",1883,60)

client.loop_forever()

