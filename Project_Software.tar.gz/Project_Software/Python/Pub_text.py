
# PUB_MES
import paho.mqtt.client as mqtt


named_tuple = time.localtime() # get struct_time
time_string = time.strftime("[%m_%d_%Y]_[%H:%M:%S]", named_tuple)

# This is the Publisher
client = mqtt.Client()
client.connect("test.mosquitto.org", 1883, 60)
for i in range(1000):
    client.publish("KJPIE", "Hello {}".format(i+1))
    client.publish("KJPIE", "cam1 = " + str(time_string))
    i += 1

client.disconnect()