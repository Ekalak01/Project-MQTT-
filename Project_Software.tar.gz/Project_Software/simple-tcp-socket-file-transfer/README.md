<a href="https://scan.coverity.com/projects/simple-tcp-socket-file-transfer">
  <img alt="Coverity Scan Build Status"
       src="https://scan.coverity.com/projects/17838/badge.svg"/>
</a><br>

# simple-tcp-socket-file-transfer

Tcp socket written to send send a file from one side to other end using tcp raw tcp socket.
