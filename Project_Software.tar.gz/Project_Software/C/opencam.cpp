#include <opencv2/highgui.hpp>
// g++ opencam.cpp -o opencam `pkg-config --cflags --libs opencv --iostream`
using namespace std;
using namespace cv;

int main() {
  
  VideoCapture cap(0);
  if(!cap.isOpened())
  {
    printf("Error Cam isnt Open  \n");
    return -1;
  }
  while(true)
  {
    Mat frame;
    cap.read(frame);
    imshow("camera", frame);
    if(waitKey(30)==27)
    {
      return 0 ;
    }
  }
}