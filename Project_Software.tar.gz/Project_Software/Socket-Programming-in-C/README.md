# Socket Programming in C
File transmission over TCP sockets in Linux system.

## Compile

    make
    
### Usage

    ./receive_file
    ./send_file /path/to/file localhost

