from ctypes import *
so_file = "./c.so"
my_functions = CDLL(so_file)

##print(type(my_functions))
x = int(input())
y = int(input())
print(my_functions.main(1))




