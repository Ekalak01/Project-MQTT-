from ctypes import *
so_file = "./gtk.so"
my_functions = CDLL(so_file)

so2_file = "./gui_pic.so"
my_functions2 = CDLL(so2_file)
##print(type(my_functions))
print(my_functions.main(1))
#print(my_functions2.main(1))



