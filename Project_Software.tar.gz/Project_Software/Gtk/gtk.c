/*! Demo GTK+ Application
 *  M. Horauer

  gcc -Wall -g gtk.c -o gtk -lpthread  \
    `pkg-config --cflags gtk+-3.0` \
    `pkg-config --libs gtk+-3.0`
  gcc -fPIC -shared -o gtk.so gtk.c \
    `pkg-config --cflags gtk+-3.0` \
    `pkg-config --libs gtk+-3.0`
 */
#include <inttypes.h>
#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

GtkWidget *window,*window2;
GtkWidget *box, *grid, *vbox, *vbox2, *hbox1, *hbox2 ,*hbox3 ;
GtkWidget *img1, *img2, *img3 ;
GtkWidget *button1,*button2, *que ;
GtkWidget *label1, *label2, *label3,*label4, *label5, *label6 ;
GtkWidget *mainlabel , *mainlabel2 ;

//static uint32_t counter = 0;
static gboolean counter_enabled = TRUE;



static void button1_callback( GtkWidget *widget, gpointer data ) {
	counter_enabled = !counter_enabled ;
	gtk_button_set_label( data,
			counter_enabled ? "Stop" : "Start" );
    
    gtk_widget_hide(window);
    gtk_widget_show_all(window2);

}
static void show_question(GtkWidget *widget, gpointer user_data) {
  
  GtkResponseType result;
  GtkWidget *dialog;
  //GtkWidget *out;
  dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_QUESTION,
            GTK_BUTTONS_YES_NO,
            "Are you sure to quit?");

  result = gtk_dialog_run(GTK_DIALOG(dialog));
  if (result == GTK_RESPONSE_YES || result == GTK_RESPONSE_APPLY) {
    g_print( "Exit..." );
    gtk_widget_destroy(window);
    gtk_widget_destroy(window2);
     
   }
  gtk_widget_destroy(dialog);

  
}

static void button1_callback2( GtkWidget *widget, gpointer data ) {
	counter_enabled = !counter_enabled ;
	gtk_button_set_label( data,
			counter_enabled ? "Stop" : "Start" );
    gtk_widget_hide(window2);
    gtk_widget_show_all(window);

}
static void button2_callback( GtkWidget *widget, gpointer data ) {
	g_print( "Exit..." );
  //GtkWidget *Exit;
  //gtk_widget_destroy(data);
}

static void activate( GtkApplication *app, gpointer user_data ) {
    window2 = gtk_application_window_new( app );

	  gtk_window_set_title( GTK_WINDOW(window2), "Main Menu" );
	  // set the default window size (width x height) in pixels
	  gtk_window_set_default_size( GTK_WINDOW(window2), 200, 200 );
	  // set window position
	  gtk_window_set_position( GTK_WINDOW(window2), GTK_WIN_POS_CENTER );
	  // set window border width
	  gtk_container_set_border_width( GTK_CONTAINER(window2), 4 );

	  grid = gtk_grid_new ();
    gtk_container_add (GTK_CONTAINER (window2), grid);
    gtk_grid_set_column_spacing ( GTK_GRID ( grid ), 5 );
    gtk_grid_set_row_spacing ( GTK_GRID ( grid ), 5 );


    mainlabel = gtk_label_new(g_strdup_printf ("Main Menu"));
    gtk_widget_override_font(mainlabel,
                            pango_font_description_from_string("Tahoma 25"));
    //gtk_widget_set_margin_end ( mainlabel, 400 );
    gtk_grid_attach (GTK_GRID (grid), mainlabel, 3, 0, 1, 1);
    gtk_widget_set_margin_start ( mainlabel, 250 );
    gtk_widget_set_margin_end ( mainlabel, 250 );

    mainlabel2 = gtk_label_new(g_strdup_printf ("Smoke Detection"));
    gtk_widget_override_font(mainlabel2,
                            pango_font_description_from_string("Tahoma 20"));
    //gtk_widget_set_margin_end ( mainlabel, 400 );
    gtk_grid_attach (GTK_GRID (grid), mainlabel2, 3, 2, 1, 1);
    gtk_widget_set_margin_start ( mainlabel2, 250 );
    gtk_widget_set_margin_end ( mainlabel2, 250 );
    
    button2 = gtk_button_new_with_label("Start");
    g_signal_connect(button2,"clicked",G_CALLBACK(button1_callback2),button2);
    gtk_widget_set_margin_top ( button2 , 20 );
    gtk_widget_set_margin_start ( button2, 100 );
    gtk_widget_set_margin_end ( button2, 100  );
    gtk_grid_attach (GTK_GRID (grid), button2, 3, 3, 1, 1);

    que = gtk_button_new_with_label("Exit");
    gtk_widget_set_margin_top ( que , 0 );
    gtk_widget_set_margin_start ( que, 100 );
    gtk_widget_set_margin_end ( que, 100 );
    gtk_grid_attach (GTK_GRID (grid), que, 3, 4, 1, 1);
    g_signal_connect(que, "clicked", G_CALLBACK(show_question),window2); 
    g_signal_connect (que, "clicked", G_CALLBACK (button2_callback) ,window2);

    window = gtk_application_window_new( app );
	// set the title of the application window
	gtk_window_set_title( GTK_WINDOW(window), "Smk Demo" );
	// set the default window size (width x height) in pixels
	gtk_window_set_default_size( GTK_WINDOW(window), 200, 160 );
	// set window position
	gtk_window_set_position( GTK_WINDOW(window), GTK_WIN_POS_CENTER );
	// set window border width
	gtk_container_set_border_width( GTK_CONTAINER(window), 4 );


	vbox = gtk_vbox_new( 
		FALSE, 5 /*spacing*/ );
	// add the box to the application window
	gtk_container_add( GTK_CONTAINER(window), vbox );

	hbox1 = gtk_hbox_new(TRUE,2);
	gtk_box_pack_start(GTK_BOX(vbox),hbox1,TRUE,TRUE,0);

	hbox2 = gtk_hbox_new(TRUE,2);
	gtk_box_pack_start(GTK_BOX(vbox),hbox2,TRUE,TRUE,0);

	hbox3 = gtk_hbox_new(TRUE,2);
	gtk_box_pack_start(GTK_BOX(vbox),hbox3,TRUE,TRUE,0);


	img1 = gtk_image_new_from_file("1.jpg");
    gtk_container_add(GTK_CONTAINER(hbox1), img1);
    gtk_box_pack_start(GTK_BOX(hbox1), img1, FALSE, TRUE, 2);

	img2 = gtk_image_new_from_file("1.jpg");
    gtk_container_add(GTK_CONTAINER(hbox1), img2);
    gtk_box_pack_start(GTK_BOX(hbox1), img2, FALSE, TRUE, 2);

	img3 = gtk_image_new_from_file("1.jpg");
    gtk_container_add(GTK_CONTAINER(hbox1), img3);
    gtk_box_pack_start(GTK_BOX(hbox1), img3, FALSE, TRUE, 2);
	

	label1 = gtk_label_new_with_mnemonic("cam1");
    gtk_widget_override_font(label1,
                            pango_font_description_from_string("Tahoma 20"));
    gtk_widget_set_size_request(label1,260,40);
    gtk_box_pack_start( GTK_BOX(hbox2),label1 , 
		FALSE /*exapnd*/, TRUE /*fill*/, 1 /*padding*/ );

	label4 = gtk_label_new_with_mnemonic("00-00-00");
    gtk_widget_override_font(label4,
                            pango_font_description_from_string("Tahoma 20"));
    gtk_widget_set_size_request(label4,260,40);
    gtk_box_pack_start( GTK_BOX(hbox3),label4 , 
		FALSE /*exapnd*/, TRUE /*fill*/, 1 /*padding*/ );

	label2 = gtk_label_new_with_mnemonic("cam2");
    gtk_widget_override_font(label2,
                            pango_font_description_from_string("Tahoma 20"));
    gtk_widget_set_size_request(label2,260,40);
    gtk_box_pack_start( GTK_BOX(hbox2),label2 , 
		FALSE /*exapnd*/, TRUE /*fill*/, 2 /*padding*/ );

	label5 = gtk_label_new_with_mnemonic("00-00-00");
    gtk_widget_override_font(label5,
                            pango_font_description_from_string("Tahoma 20"));
    gtk_widget_set_size_request(label5,260,40);
    gtk_box_pack_start( GTK_BOX(hbox3),label5 , 
		FALSE /*exapnd*/, TRUE /*fill*/, 1 /*padding*/ );

	label3 = gtk_label_new_with_mnemonic("cam3");
    gtk_widget_override_font(label3,
                            pango_font_description_from_string("Tahoma 20"));
    gtk_widget_set_size_request(label3,260,40);
    gtk_box_pack_start( GTK_BOX(hbox2),label3 , 
		FALSE /*exapnd*/, TRUE /*fill*/, 3 /*padding*/ );

	label6 = gtk_label_new_with_mnemonic("00-00-00");
    gtk_widget_override_font(label6,
                            pango_font_description_from_string("Tahoma 20"));
    gtk_widget_set_size_request(label6,260,40);
    gtk_box_pack_start( GTK_BOX(hbox3),label6 , 
		FALSE /*exapnd*/, TRUE /*fill*/, 1 /*padding*/ );

	button1 = gtk_button_new_with_label( "Stop" );
	g_signal_connect( button1, "clicked",
		G_CALLBACK(button1_callback), button1 );
    gtk_widget_set_size_request(button1,1,1);
    gtk_box_pack_start( GTK_BOX(vbox), button1, 
		FALSE /*exapnd*/, FALSE /*fill*/, 4 /*padding*/ );
    
    que = gtk_button_new_with_label("Exit");
    g_signal_connect( que, "clicked",
		G_CALLBACK(show_question), que );
    gtk_widget_set_size_request(que,1,1);
    gtk_box_pack_start( GTK_BOX(vbox), que, 
		FALSE /*exapnd*/, TRUE /*fill*/, 5 /*padding*/ );

    gtk_widget_show_all( window2 );


    

}

int
main (int argc, char **argv) 
{

    //---------------------------------------

    int status;
    GtkApplication *app;
	app = gtk_application_new( NULL, G_APPLICATION_FLAGS_NONE );

	g_signal_connect( app, "activate", 
		G_CALLBACK(activate), NULL );
	// start the application main loop (blocking call)
    
	status = g_application_run( G_APPLICATION(app), argc, argv );

	// decrease the reference count to the object
	g_object_unref( app );

    
	return status ;
}
////////////////////////////////////////////////////////////////

