import numpy as np
import cv2

img = cv2.imread('1.jpg',1)
cv2.imshow('image',img)
k = cv2.waitKey(20000)
if k == k:         # กด ESC ออก
    print("esc")
    cv2.destroyAllWindows()
elif k == ord('s'): # กด 's' บันทึกภาพ และ ออก
     cv2.imwrite('1.jpg',img)
     cv2.destroyAllWindows()
