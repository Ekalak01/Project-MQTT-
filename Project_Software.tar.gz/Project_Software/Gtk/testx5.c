#include <gtk/gtk.h>
#include <glib.h>
#include <glib/gprintf.h>

/*! Demo GTK+ Application
 *  M. Horauer

 gcc -Wall -g testx5.c -o testx5 -lpthread  \
    `pkg-config --cflags gtk+-3.0` \
    `pkg-config --libs gtk+-3.0`
 */

int main(int argc, char *argv[])
{
    GtkWidget *mainwindow;
    GtkWidget *popwindow;
    GtkWidget *label;

    gtk_init(&argc, &argv);

    mainwindow = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_position(GTK_WINDOW(mainwindow), GTK_WIN_POS_CENTER);
    //gtk_window_set_decorated(GTK_WINDOW(mainwindow), FALSE);
    gtk_window_set_default_size(GTK_WINDOW(mainwindow), 500,500);
    gtk_widget_show_all(mainwindow);

    popwindow = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_keep_above(GTK_WINDOW(popwindow), TRUE);
    gtk_window_set_modal(GTK_WINDOW(popwindow), TRUE);
    //gtk_window_set_decorated (GTK_WINDOW (popwindow), FALSE);
    gtk_window_set_resizable (GTK_WINDOW(popwindow), FALSE);
    gtk_window_set_position( GTK_WINDOW (popwindow), (GtkWindowPosition)GTK_WIN_POS_CENTER);
    gtk_window_set_transient_for(GTK_WINDOW(popwindow),GTK_WINDOW(mainwindow));

    label = gtk_label_new(g_strdup_printf ("My GTK version is %d.%d.%d", gtk_major_version, gtk_minor_version, gtk_micro_version));
    gtk_container_add(GTK_CONTAINER(popwindow), label);
    gtk_widget_show(label);
    gtk_widget_show(popwindow);

    label = gtk_label_new(g_strdup_printf ("My GTK version is %d.%d.%d", gtk_major_version, gtk_minor_version, gtk_micro_version));
    gtk_container_add(GTK_CONTAINER(mainwindow), label);
    gtk_widget_show(label);
    gtk_widget_show(mainwindow);



    g_signal_connect(G_OBJECT(mainwindow), "destroy",
        G_CALLBACK(gtk_main_quit), NULL);
    
    gtk_main();

    return 0;
}