/*! Demo GTK+ Application
 *  M. Horauer

 gcc -Wall -g gui_test.c -o gui_test -lpthread  \
    `pkg-config --cflags gtk+-3.0` \
    `pkg-config --libs gtk+-3.0`
 */
#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>

static gboolean counter_enabled = FALSE;

typedef struct {
  GtkWidget *window;
  GtkWidget *img1;
  GtkWidget *img2;
  GtkWidget *img3;
  GtkWidget *greeterlable;
  GtkWidget *button1;
} gWidgets;

/**************************************************************** Button */

static void button1_callback( GtkWidget *widget, gpointer data ) {
	counter_enabled = !counter_enabled;
	gtk_button_set_label( data,
			counter_enabled ? "Running" : "Paused" );
}

static void button2_callback( GtkWidget *widget, gpointer data ) {
	g_print( "Exit..." );
}

static void
activate (GtkApplication *app, gpointer user_data)
{
    GtkWidget *box, *fbox,*ebox1, *ebox2, *ebox3;
    GtkWidget *labelbutton1;
    GtkWidget *button2;
    GtkWidget *grid;
    gWidgets *w = (gWidgets *)user_data;

    

    /* create a window with title, default size,and icons */
    w->window = gtk_application_window_new(app);
    gtk_window_set_application(GTK_WINDOW(w->window), GTK_APPLICATION (app));
    gtk_window_set_title(GTK_WINDOW(w->window), "Smoke detector");
    gtk_window_set_default_size(GTK_WINDOW(w->window), 500,500);
    gtk_window_set_resizable (GTK_WINDOW(w->window), FALSE);
    
    grid      = gtk_grid_new ();

    box = gtk_box_new(GTK_ORIENTATION_VERTICAL,2);
    gtk_container_add(GTK_CONTAINER(w->window), GTK_WIDGET(box));

    
    
    labelbutton1 = gtk_button_new_with_label("Start");
    g_signal_connect(labelbutton1,"clicked",G_CALLBACK(button1_callback),labelbutton1);
    gtk_grid_attach (GTK_GRID(grid), labelbutton1, 0, 0, 1, 1);
    
    button2 = gtk_button_new_with_label( "Exit" );
	  g_signal_connect( button2, "clicked",
		G_CALLBACK(button2_callback), NULL );
	  g_signal_connect_swapped( button2, "clicked", 
		G_CALLBACK( gtk_widget_destroy), w->window );
    gtk_grid_attach (GTK_GRID(grid), button2, 1, 0, 1, 1);

    /* display all widgets */
    gtk_widget_show_all(GTK_WIDGET(w->window));
}



/*********************************************************************** main */
int
main (int argc, char **argv)
{
    GtkApplication *app;
    int status;
    gWidgets *w = g_malloc(sizeof(w));

    gtk_init (&argc,&argv);

    app = gtk_application_new ("org.gtk.example",G_APPLICATION_FLAGS_NONE);

    g_signal_connect (app, "activate", G_CALLBACK (activate), (gpointer)w);
    status = g_application_run (G_APPLICATION (app), argc, argv);
    g_object_unref (app);

    g_free(w);
    return status;
}

