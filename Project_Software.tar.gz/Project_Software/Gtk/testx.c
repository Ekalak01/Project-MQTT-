/*! Demo GTK+ Application
 *  M. Horauer

 gcc -Wall -g testx.c -o testx -lpthread  \
    `pkg-config --cflags gtk+-3.0` \
    `pkg-config --libs gtk+-3.0`
 */
#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>

static gboolean counter_enabled = FALSE;

typedef struct {
  GtkWidget *window;
  GtkWidget *img1;
  GtkWidget *img2;
  GtkWidget *img3;
  GtkWidget *grid;
} gWidgets;

/**************************************************************** Button */

static void button1_callback( GtkWidget *widget, gpointer data ) {
	counter_enabled = !counter_enabled;
	gtk_button_set_label( data,
			counter_enabled ? "Running" : "Paused" );
}

static void button2_callback( GtkWidget *widget, gpointer data ) {
	g_print( "Exit..." );
  //GtkWidget *Exit;
  //gtk_widget_destroy(data);
}


/**************************************************************** first_dialog */

static void first_dialog(void)
{
    // This creates (but does not yet display) a message dialog with
    // the given text as the title.
    GtkWidget* hello = gtk_message_dialog_new(
        NULL, GTK_DIALOG_MODAL, GTK_MESSAGE_INFO, GTK_BUTTONS_OK,
        "Hi, I'm a message dialog!");

    // The (optional) secondary text shows up in the "body" of the
    // dialog. Note that printf-style formatting is available.
    gtk_message_dialog_format_secondary_text(
        GTK_MESSAGE_DIALOG(hello),
        "Smoke detector");

    // This displays our message dialog as a modal dialog, waiting for
    // the user to click a button before moving on. The return value
    // comes from the :response signal emitted by the dialog. By
    // default, the dialog only has an OK button, so we'll get a
    // GTK_RESPONSE_OK if the user clicked the button. But if the user
    // destroys the window, we'll get a GTK_RESPONSE_DELETE_EVENT.
    int response = gtk_dialog_run(GTK_DIALOG(hello));

    printf("response was %d (StartSS=%d, DELETE_EVENT=%d)\n",
           response, GTK_RESPONSE_OK, GTK_RESPONSE_DELETE_EVENT);

    // If we don't destroy the dialog here, it will still be displayed
    // (in back) when the second dialog below is run.
    gtk_widget_destroy(hello);
}

static void show_question(GtkWidget *widget, gpointer window) {
  GtkResponseType result;
  GtkWidget *dialog;
  //GtkWidget *out;
  dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_QUESTION,
            GTK_BUTTONS_YES_NO,
            "Are you sure to quit?");
  
  result = gtk_dialog_run(GTK_DIALOG(dialog));
  if (result == GTK_RESPONSE_YES || result == GTK_RESPONSE_APPLY) {
    g_print( "Exit..." );
    gtk_widget_destroy(window); 
     
   }
  gtk_widget_destroy(dialog);

  
}

/**************************************************************** MAIN WINDOW */

static void
activate (GtkApplication *app, gpointer user_data)
{
    //GtkWidget *ebox1, *ebox2, *ebox3;
    //GtkWidget *labelbutton1;
    GtkWidget *que,*label,*start;
    gWidgets *w = (gWidgets *)user_data;
    //Declarations
    w->window = gtk_application_window_new(app);
    gtk_window_set_application(GTK_WINDOW(w->window), GTK_APPLICATION (app));
    gtk_window_set_title(GTK_WINDOW(w->window), "Smoke detector");
    //gtk_window_set_position( GTK_WINDOW (w->window), (GtkWindowPosition)GTK_WIN_POS_CENTER);
    gtk_window_set_decorated(GTK_WINDOW(w->window), TRUE);
    gtk_window_fullscreen(GTK_WINDOW(w->window));
    //gtk_window_set_default_size(GTK_WINDOW(w->window), 500,600);
    gtk_widget_show_all(w->window);
  

    /*
    next_to_program = gtk_button_new_with_label ("Start");
    g_signal_connect_swapped (button, "clicked", G_CALLBACK (gtk_widget_destroy), desktop);
    gtk_grid_attach (GTK_GRID (desktop), button, 3, 3, 1, 1);

     Here we construct the container that is going pack our buttons */
    
    w->grid = gtk_grid_new ();
    gtk_container_add (GTK_CONTAINER (w->window), w->grid);
    gtk_grid_set_column_spacing ( GTK_GRID ( w->grid ), 5 );
    gtk_grid_set_row_spacing ( GTK_GRID ( w->grid ), 5 );

    
    w->img1 = gtk_image_new_from_file("1.jpg");
    gtk_grid_attach (GTK_GRID (w->grid), w->img1, 0, 0, 1, 1);
    
    w->img2 = gtk_image_new_from_file("1.jpg");
    gtk_grid_attach (GTK_GRID (w->grid), w->img2, 1, 0, 1, 1);

    w->img3 = gtk_image_new_from_file("1.jpg");
    gtk_grid_attach (GTK_GRID (w->grid), w->img3, 2, 0, 1, 1);

    label = gtk_label_new(g_strdup_printf ("Cam ID   : "));
    gtk_widget_set_margin_end ( label, 400 );
    gtk_grid_attach (GTK_GRID (w->grid), label, 0, 2, 1, 1);
    label = gtk_label_new(g_strdup_printf ("Cam ID   : "));
    gtk_widget_set_margin_end ( label, 400 );
    gtk_widget_set_margin_start ( label, 0 );
    gtk_grid_attach (GTK_GRID (w->grid), label, 1, 2, 1, 1);
    label = gtk_label_new(g_strdup_printf ("Cam ID  : "));
    gtk_widget_set_margin_end ( label, 400 );
    gtk_widget_set_margin_start ( label, 0 );
    gtk_grid_attach (GTK_GRID (w->grid), label, 2, 2, 1, 1);

    label = gtk_label_new(g_strdup_printf ("Location : "));
    gtk_widget_set_margin_end ( label, 400 );
    gtk_widget_set_margin_start ( label, 0 );
    gtk_grid_attach (GTK_GRID (w->grid), label, 0, 3, 1, 1);
    label = gtk_label_new(g_strdup_printf ("Location : "));
    gtk_widget_set_margin_end ( label, 400 );
    gtk_widget_set_margin_start ( label, 0 );
    gtk_grid_attach (GTK_GRID (w->grid), label, 1, 3, 1, 1);
    label = gtk_label_new(g_strdup_printf ("Location : "));
    gtk_widget_set_margin_end ( label, 400 );
    gtk_widget_set_margin_start ( label, 0 );
    gtk_grid_attach (GTK_GRID (w->grid), label, 2, 3, 1, 1);

    que = gtk_button_new_with_label("Exit");
    gtk_widget_set_margin_top ( que , 25 );
    gtk_widget_set_margin_start ( que, 10 );
    gtk_widget_set_margin_end ( que, 400 );
    gtk_grid_attach (GTK_GRID (w->grid), que, 0, 4, 1, 1);
    g_signal_connect(que, "clicked", G_CALLBACK(show_question),w->window); 
    g_signal_connect (que, "clicked", G_CALLBACK (button2_callback) ,w->window);


    start = gtk_button_new_with_label("Start");
    g_signal_connect(start,"clicked",G_CALLBACK(button1_callback),start);
    gtk_widget_set_margin_top ( start , 25 );
    gtk_widget_set_margin_start ( start, 200 );
    gtk_widget_set_margin_end ( start, 200 );
    gtk_grid_attach (GTK_GRID (w->grid), start, 1, 4, 1, 1);
  

    /* display all widgets */
    gtk_widget_show_all(GTK_WIDGET(w->window));

}
/*********************************************************************** main */
int
main (int argc, char **argv)
{
    

    GtkApplication *app;
    int status;
    gtk_init(&argc, &argv);

    first_dialog();
    gWidgets *w = g_malloc(sizeof(w));


    app = gtk_application_new ("org.gtk.example",G_APPLICATION_FLAGS_NONE);

    g_signal_connect (app, "activate", G_CALLBACK (activate), (gpointer)w);
    status = g_application_run (G_APPLICATION (app), argc, argv);
    g_object_unref (app);

    g_free(w);
    return status;
}
