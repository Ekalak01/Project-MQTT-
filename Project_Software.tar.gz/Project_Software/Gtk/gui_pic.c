/*! Demo GTK+ Application
 *  M. Horauer

 gcc -Wall -g gui_pic.c -o gui_pic -lpthread  \
    `pkg-config --cflags gtk+-3.0` \
    `pkg-config --libs gtk+-3.0`
 gcc -fPIC -shared -o gui_pic.so gui_pic.c \
    `pkg-config --cflags gtk+-3.0` \
    `pkg-config --libs gtk+-3.0`
 */
#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>


static gboolean counter_enabled = FALSE;

typedef struct {
  GtkWidget *window;
  GtkWidget *img1;
  GtkWidget *img2;
  GtkWidget *img3;
  GtkWidget *greeterlable;
  GtkWidget *button1;
} gWidgets;

/**************************************************************** Button */

static void button1_callback( GtkWidget *widget, gpointer data ) {
	counter_enabled = !counter_enabled;
	gtk_button_set_label( data,
			counter_enabled ? "Running" : "Paused" );
}

static void button2_callback( GtkWidget *widget, gpointer data ) {
	g_print( "Exit..." );
}


/************************************************************* IMAGE CALLBACK */
static void
imgCallback(GtkWidget *widget, GdkEvent *event, gpointer user_data)
{
  GtkWidget *dialog;
  GtkFileFilter *filter;
  gint res;
  gWidgets *w = (gWidgets *)user_data;

  filter = gtk_file_filter_new();
  dialog = gtk_file_chooser_dialog_new("Open File",
                                       GTK_WINDOW(w->window),
                                       GTK_FILE_CHOOSER_ACTION_OPEN,
                                       "_Cancel",
                                       GTK_RESPONSE_CANCEL,
                                       "_Open",
                                       GTK_RESPONSE_ACCEPT,
                                       NULL);
  gtk_file_filter_add_mime_type(GTK_FILE_FILTER(filter), "image/jpg");
  gtk_file_filter_add_mime_type(GTK_FILE_FILTER(filter), "image/png");
  gtk_file_chooser_set_filter(GTK_FILE_CHOOSER(dialog),filter);

  res = gtk_dialog_run (GTK_DIALOG (dialog));
  if (res == GTK_RESPONSE_ACCEPT)
    {
      gchar *filename;
      GtkFileChooser *chooser = GTK_FILE_CHOOSER (dialog);
      filename = gtk_file_chooser_get_filename (chooser);
      gtk_image_set_from_file(GTK_IMAGE(w->img1), filename);
      g_free (filename);
    }

  gtk_widget_destroy (dialog);
}

/*********************************************************************** main 
static void
activate2 (GtkWidget *widget, gpointer user_data)
{
    GtkWidget *grid,*box4;
    gWidgets *w = (gWidgets *)user_data;
    gtk_window_set_type_hint(GTK_WINDOW(w->window), GDK_WINDOW_TYPE_HINT_DIALOG);
    gtk_window_set_keep_above(GTK_WINDOW(w->window), TRUE);
    grid = gtk_grid_new ();
    
    gtk_container_add (GTK_CONTAINER (w->window), grid);
    gtk_grid_set_column_spacing ( GTK_GRID ( grid ), 5 );
    gtk_grid_set_row_spacing ( GTK_GRID ( grid ), 5 );
  

    box4 = gtk_button_new_with_label ("Quit");
    g_signal_connect_data ((box4), ("clicked"), (((GCallback) (gtk_widget_destroy))), (w->window), NULL, G_CONNECT_SWAPPED);
    //g_signal_connect_swapped (button, "clicked", G_CALLBACK (button2_callback) ,NULL);
    gtk_grid_attach (GTK_GRID (grid), box4, 0, 3, 1, 1);
    

}
*/
double activated(int argc, char **argv, gpointer user_data)
{
    GtkWidget *mainwindow;
    GtkWidget *popwindow;
    GtkWidget *label;
    gWidgets *w = (gWidgets *)user_data;
    //gtk_widget_destroy(w->window);
    gtk_init(&argc, &argv);

    mainwindow = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_position(GTK_WINDOW(mainwindow), GTK_WIN_POS_CENTER);
    //gtk_window_set_decorated(GTK_WINDOW(mainwindow), FALSE);
    gtk_window_set_default_size(GTK_WINDOW(mainwindow), 500,500);
    gtk_widget_show_all(mainwindow);

    popwindow = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_keep_above(GTK_WINDOW(popwindow), TRUE);
    //gtk_window_set_modal(GTK_WINDOW(popwindow), TRUE);
    //gtk_window_set_decorated (GTK_WINDOW (popwindow), FALSE);
    gtk_window_set_resizable (GTK_WINDOW(popwindow), FALSE);
    gtk_window_set_position( GTK_WINDOW (popwindow), (GtkWindowPosition)GTK_WIN_POS_CENTER);
    gtk_window_set_transient_for(GTK_WINDOW(popwindow),GTK_WINDOW(mainwindow));

    label = gtk_label_new(g_strdup_printf ("My GTK version is %d.%d.%d", gtk_major_version, gtk_minor_version, gtk_micro_version));
    gtk_container_add(GTK_CONTAINER(popwindow), label);
    gtk_widget_show(label);
    gtk_widget_show(popwindow);


    return 0;
}

/**************************************************************** MAIN WINDOW */
static void
activate (GtkApplication *app, gpointer user_data)
{
    GtkWidget *box,*ebox1, *ebox2, *ebox3;
    GtkWidget *labelbutton1;
    GtkWidget *button2;

    gWidgets *w = (gWidgets *)user_data;
    
    /* create a window with title, default size,and icons */
    w->window = gtk_application_window_new(app);
    gtk_window_set_application(GTK_WINDOW(w->window), GTK_APPLICATION (app));
    gtk_window_set_title(GTK_WINDOW(w->window), "Smoke detector");
    gtk_window_set_default_size(GTK_WINDOW(w->window), 500,500);
    gtk_widget_show_all(w->window);
    //gtk_window_set_default_icon_from_file("icon.png", NULL);

    box = gtk_box_new(GTK_ORIENTATION_VERTICAL,2);
    gtk_container_add(GTK_CONTAINER(w->window), GTK_WIDGET(box));

    w->img1 = gtk_image_new_from_file("1.jpg");
    gtk_container_add(GTK_CONTAINER(box), w->img1);
    gtk_widget_show(w->img1);
    
    labelbutton1 = gtk_button_new_with_label("Start");
    g_signal_connect(labelbutton1,"clicked",G_CALLBACK(button1_callback),labelbutton1);
    gtk_widget_show(labelbutton1);   

    button2 = gtk_button_new_with_label( "Exit" );
	  //g_signal_connect( button2, "clicked",G_CALLBACK(button2_callback), NULL );
    g_signal_connect( button2, "clicked", G_CALLBACK( gtk_widget_destroy), button2 );
    //g_signal_connect(button2,"clicked",G_CALLBACK(activated),box);
    
    gtk_box_pack_start(GTK_BOX(box), GTK_WIDGET(button2), FALSE, TRUE, 4);

   
    /* display all widgets */
    gtk_widget_show_all(GTK_WIDGET(w->window));
}




/*********************************************************************** main */
int
main (int argc, char **argv)
{
    GtkApplication *app;
    int status;
    gWidgets *w = g_malloc(sizeof(w));

    app = gtk_application_new ("org.gtk.example",G_APPLICATION_FLAGS_NONE);

    g_signal_connect (app, "activate", G_CALLBACK (activate), (gpointer)w);
    status = g_application_run (G_APPLICATION (app), argc, argv);
    g_object_unref (app);

    g_free(w);
    return status;
}
