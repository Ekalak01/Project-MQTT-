/*! Demo GTK+ Application
 *  M. Horauer

 gcc -Wall -g testx4.c -o testx4 -lpthread  \
    `pkg-config --cflags gtk+-3.0` \
    `pkg-config --libs gtk+-3.0`
 */
#include <gtk/gtk.h>
#include <string.h>
#include <stdlib.h>

GtkWidget *notebook;

static void
go_next_page (GtkWidget *widget,
              gpointer data)
{
    gtk_notebook_next_page (GTK_NOTEBOOK (notebook));
}


static GtkWidget*
init_notebook_widgets (void)
/* Return: GtkNotebook pointer */
{
    GtkWidget *page1, *page2, *page3, *page4, \
              *label1, *label2, *label3, *label4, \
              *next_button;

    notebook = gtk_notebook_new ();
    next_button = gtk_button_new_with_mnemonic ("_Next page");
    g_signal_connect (G_OBJECT (next_button), "clicked",
                      G_CALLBACK (go_next_page), NULL);

    page1 = gtk_box_new (TRUE, 5);
    label1 = gtk_label_new ("This is first page!");
    gtk_box_pack_start (GTK_BOX (page1), GTK_WIDGET(label1),FALSE,TRUE,1);


    page2 = gtk_box_new (TRUE, 5);
    label2 = gtk_label_new ("This is second page!");
    gtk_box_pack_start (GTK_BOX (page2), GTK_WIDGET(label2),FALSE,TRUE,2);


    page3 = gtk_box_new (TRUE, 5);
    label3 = gtk_label_new ("This is third page!");
    gtk_box_pack_start (GTK_BOX (page3), GTK_WIDGET(label3),FALSE,TRUE,3);
    

    page4 = gtk_box_new (TRUE, 5);
    label4 = gtk_label_new ("This is fourth page!");
    gtk_box_pack_start (GTK_BOX (page4), GTK_WIDGET(label4),FALSE,TRUE,4);
   

    gtk_notebook_append_page (GTK_NOTEBOOK (notebook), page1,
                              gtk_label_new ("Page 1"));
    gtk_notebook_append_page (GTK_NOTEBOOK (notebook), page2,
                              gtk_label_new ("Page 2"));
    gtk_notebook_append_page (GTK_NOTEBOOK (notebook), page3,
                              gtk_label_new ("Page 3"));
    gtk_notebook_append_page (GTK_NOTEBOOK (notebook), page4,
                              gtk_label_new ("Page 4"));

    gtk_notebook_set_tab_pos (GTK_NOTEBOOK (notebook), GTK_POS_BOTTOM);

    return notebook;
}
/*********************************************************************** main */
int
main (int argc, char **argv)
{
    GtkApplication *notebook;
    int status;

    notebook = gtk_application_new ("org.gtk.example",G_APPLICATION_FLAGS_NONE);
    status = g_application_run (G_APPLICATION (notebook), argc, argv);
    g_object_unref (notebook);

    
    return status;
}

